<?php

namespace App\Providers;

use Illuminate\Foundation\Support\Providers\RouteServiceProvider as ServiceProvider;



class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //s
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        parent::boot();

    }
}
