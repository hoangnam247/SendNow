<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Tymon\JWTAuth\Exceptions\JWTException;
use Tymon\JWTAuth\Facades\JWTAuth;
use App\Models\User;

class AuthController extends Controller
{
    //
    public function __construct()
    {
        $this->middleware('auth:api', ['except' => ['login' ,'refresh']]);
    }

      public function login()
    {
        $credentials = request(['email', 'password']);

            // Kiểm tra xác thực người dùng với JWTAuth
            if (! $token = JWTAuth::attempt($credentials)) {
                return response()->json(['error' => 'Unauthorized'], 401);
            }
            $data = [
                'sub' => auth('api')->user()->id,
                'random' => rand().time(),
                'exp' => time() + config('jwt.refresh_ttl')
            ];
            $refreshToken =  JWTAuth::getJWTprovider()->encode($data);
           
            return $this->respondWithToken($token,$refreshToken);
    }

        
   
    public function profile()
    {
        try{
            return response()->json(auth('api')->user());

        }catch (JWTException $exception) {
            return response()->json(['error' => 'Unauthorized'], 401);
        }

    }

    public function logout()
    {
        auth('api')->logout();

        return response()->json(['message' => 'Successfully logged out']);
    }

    public function refresh()
    {
        $refreshToken = request()->refresh_token;
        try {
            $decode = JWTAuth::getJWTprovider()->decode($refreshToken);
            // xu ly cap lai token moi
            // lay thong tin user
            $user = User::find($decode['sub']);
            if(!$user){
                return response()->json(['error' => 'User no found'],404);
            }
            JWTAuth::invalidate(JWTAuth::getToken());


            $token = auth('api')->login($user);

            $refreshToken = $this->createRefreshToken();

            return $this->respondWithToken($token, $refreshToken);
        } catch (JWTException $exception) {
            return response()->json(['error' => 'Refresh Token Invalid'], 500);
        }
    }
    
    protected function respondWithToken($token, $refreshToken)
    {
        $user = JWTAuth::user();
        return response()->json([
            'refresh_token' => $refreshToken,
            'access_token' => $token,
            'token_type' => 'bearer',
            'expires_in' => config('jwt.ttl') * 60 ,// Lấy từ config
            'user' => [
            'id' => $user->id,
            'name' => $user->name,
            'email' => $user->email
        ]
        ]);
    }

    private function createRefreshToken(){
        $data = [
            'sub' => auth('api')->user()->id,
            'random' => rand().time(),
            'exp' => time() + config('jwt.refresh_ttl')
        ];
        $refreshToken =  JWTAuth::getJWTprovider()->encode($data);
       
        return  $refreshToken;
    }

}
